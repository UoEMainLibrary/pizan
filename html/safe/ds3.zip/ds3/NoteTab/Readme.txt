
README.TXT for NoteTab Pro� 4.95 (Full Version)
================================

Welcome to NoteTab Pro! A leading-edge, award-winning text and HTML editor.

If you are reading this file from your new NoteTab program, open the special file Readme.otl to quickly discover some of its most original features. If you are not familiar with technical terms, you will find help by viewing the Glossary.otl file that can be accessed from the Help menu. See the WhatsNew.txt file for information on the most recent changes made to the program. Tip: put the cursor on any of these file names and hit the F7 function key to open it immediately.


Contents
--------
 1. Introduction
 2. Installation
 3. Dictionaries and Thesaurus
 4. Help Files
 5. Technical Support
 6. Upgrade Policy
 7. Feedback


1. Introduction
---------------
NoteTab Pro is a leading-edge text editor and HTML coding tool, and an ideal Notepad replacement. Winner of top Shareware industry awards since 1998, this elegant application does it all: you can handle multiple large files with a simple tabbed interface, use a spell-checker and thesaurus, format text, use multiple undo, and bookmark documents. You can build templates, use powerful system-wide searches, and do global multi-line replacements.

Its Clipbook feature lets you create and organize clips, which can range from text macros to complete mini-applications, using a simple scripting language with enough features to satisfy any power user; a bunch of handy clip libraries is included. 

Web authors will love the HTML clip library, just one of a load of features that make NoteTab a great code-based HTML editor. Other gems include text-to-HTML conversion, tag stripping, and tools for adding links and color codes.

There's a lot more to NoteTab Pro -- and it's an unbeatable value at US$19.95.


2. Installation
---------------
You can install this release over a previous copy if you want to keep all your settings. Just extract the Setup.exe file from the .zip package and execute it.

How to Uninstall
................
You can uninstall NoteTab by using the Control Panel's Add/Remove Programs dialog box or the Uninstall NoteTab icon in the Start menu. Note that this will delete your program settings. If you want to save your settings, you should make a copy of the .ini file prior to uninstalling.

IMPORTANT - WINDOWS NT USERS: If NoteTab was installed with Administrative privileges, you should then also uninstall NoteTab under these conditions. Otherwise, NoteTab might not be completely removed from your system.


3. Dictionaries and Thesaurus
-----------------------------
To keep the size of the commercial distribution package down, dictionaries and the thesaurus file are not included. However, you can download all these files for free by visiting one of the NoteTab web sites listed below.

http://www.notetab.com/dictionaries.htm  (main site)
or
http://www.notetab.ch/dictionaries.htm  (Swiss site)

The web site also provides a large collection of Clipbook libraries created by NoteTab users. Other resources include sounds for the toolbar, "Made with NoteTab" Web page banners, and a list of answers to frequently asked questions.


4. Help Files
-------------
NoteTab supports two different kinds of Help documents, HTML Help and the older WinHelp. Because HTML Help is appreciated a lot more than WinHelp, NoteTab is now distributed over the Internet with only HTML Help. However, some rare systems (Windows 95 and NT4) are not configured to display HTML Help. If that is your case, you can download the WinHelp versions of the NoteTab documentation from the following Web page:

http://www.notetab.com/winhelp.htm


5. Technical Support
--------------------
Free technical support is available to registered users of NoteTab Pro and NoteTab Standard. If you have a problem installing or running your registered copy of NoteTab, you can ask for help by writing to <support@fookes.com>. If you have problems ordering or getting your registered copy of NoteTab, please contact the online distributor's customer support (Digital River: <custserv@DigitalRiver.com>), or write to <sales@fookes.com>. Please do not use these e-mail addresses for questions about using NoteTab. We provide a free mailing list to help you with all non-customer support issues (see below).

If you have questions about using NoteTab or would like to learn some time-saving tricks from other users, then please join the NoteTab mailing list (even if it is just for one question). It is free for everyone (registered and non-registered users). The NoteTab author frequently answers questions and also uses the list to announce updates and changes to NoteTab. You will find more information about this list on the following web page:

   http://www.notetab.com/maillist.htm (main site)
or
   http://www.notetab.ch/maillist.htm (Swiss site)

You will also find useful information, links, and other NoteTab-related resources (Clipbook libraries, patches, dictionaries, answers to common questions, etc.) by visiting one of the NoteTab web sites listed below:

   http://www.notetab.com/ (main site)
or
   http://www.notetab.ch/ (Swiss site)


6. Upgrade Policy
-----------------
Minor updates and maintenance releases are free for users of the corresponding major version. In other words, if you purchased NoteTab Pro v4.00, all updates up to v4.99 inclusive are available for free. Major upgrades (version 5.*, 6.*, etc.) are available to registered users of previous versions at a 50% discount. However, the upgrade is free for those who purchased the corresponding version of NoteTab 120 days prior to the release of a major upgrade.


7. Feedback
-----------
Bug reports, criticism, and comments are very welcome. You can send suggestions to the NoteTab mailing list, or you can write directly to us by sending your e-mail to <feedback@fookes.com>.


Hope you enjoy using NoteTab!
-Eric G.V. Fookes

_______________________________________________________________________________
           NoteTab� is a trademark of Fookes Software, Switzerland 
            Copyright � 1995-2003, Fookes Software, Switzerland
                         - All Rights Reserved -

Windows is a trademark of Microsoft Corporation registered in the U.S. and other countries.
All other trademarks and service marks are the property of their respective owners.
